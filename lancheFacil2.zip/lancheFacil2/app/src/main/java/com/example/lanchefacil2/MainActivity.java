package com.example.lanchefacil2;

import android.app.Activity;

public class MainActivity extends Activity {
}
