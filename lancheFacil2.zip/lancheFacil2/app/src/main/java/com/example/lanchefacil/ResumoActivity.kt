package com.example.lanchefacil

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lanchefacil2.R

class ResumoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resumo)

        val nome = intent.getStringExtra("nomeCliente")
        val lanche = intent.getStringExtra("lancheEscolhido")

        val txtResumo = findViewById<TextView>(R.id.txtResumo)
        txtResumo.text = "Olá, $nome!\nSeu pedido: $lanche"

        val btnVoltar = findViewById<Button>(R.id.btnVoltarInicio)
        btnVoltar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            // limpa o histórico de atividades para recomeçar do início
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
        }
    }
}
