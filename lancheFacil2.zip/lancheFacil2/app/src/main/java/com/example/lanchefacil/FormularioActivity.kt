package com.example.lanchefacil

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import androidx.appcompat.app.AppCompatActivity
import com.example.lanchefacil2.R

class FormularioActivity : AppCompatActivity() {

    private var lancheSelecionado = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario)

        val inputNome = findViewById<TextInputEditText>(R.id.inputNome)
        val btnHamburguer = findViewById<Button>(R.id.btnHamburguer)
        val btnHotdog = findViewById<Button>(R.id.btnHotdog)
        val btnConfirmar = findViewById<Button>(R.id.btnConfirmar)

        btnHamburguer.setOnClickListener {
            lancheSelecionado = "Hambúrguer"
        }

        btnHotdog.setOnClickListener {
            lancheSelecionado = "Cachorro-Quente"
        }

        btnConfirmar.setOnClickListener {
            val nome = inputNome.text.toString()

            if (nome.isEmpty() || lancheSelecionado.isEmpty()) {
                Toast.makeText(this, "Digite seu nome e escolha um lanche!", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, ResumoActivity::class.java)
                intent.putExtra("nomeCliente", nome)
                intent.putExtra("lancheEscolhido", lancheSelecionado)
                startActivity(intent)
            }
        }
    }
}
