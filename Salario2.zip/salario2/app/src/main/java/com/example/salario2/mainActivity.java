package com.example.salario2;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class mainActivity extends AppCompatActivity {

    EditText etSalario;
    RadioGroup rgPercentual;
    RadioButton rb40, rb45, rb50;
    Button btnCalcular;
    TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSalario = findViewById(R.id.et_salario);
        rgPercentual = findViewById(R.id.rg_percentual);
        rb40 = findViewById(R.id.rb_40);
        rb45 = findViewById(R.id.rb_45);
        rb50 = findViewById(R.id.rb_50);
        btnCalcular = findViewById(R.id.btn_calcular);
        tvResultado = findViewById(R.id.tv_resultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String salarioStr = etSalario.getText().toString();

                if (salarioStr.isEmpty()) {
                    Toast.makeText(mainActivity.this, "Digite o salário!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double salario = Double.parseDouble(salarioStr);
                double percentual = 0.0;

                int selectedId = rgPercentual.getCheckedRadioButtonId();

                if (selectedId == R.id.rb_40) {
                    percentual = 0.40;
                } else if (selectedId == R.id.rb_45) {
                    percentual = 0.45;
                } else if (selectedId == R.id.rb_50) {
                    percentual = 0.50;
                } else {
                    Toast.makeText(mainActivity.this, "Selecione um percentual!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double novoSalario = salario + (salario * percentual);
                tvResultado.setText(String.format("Novo salário: R$ %.2f", novoSalario));
            }
        });
    }
}
