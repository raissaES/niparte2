package com.example.check1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.check1.R;

public class MainActivity extends AppCompatActivity {

    CheckBox cbArroz, cbLeite, cbCarne, cbFeijao, cbCoca;
    Button btnCalcular;
    TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cbArroz = findViewById(R.id.cb_arroz);
        cbLeite = findViewById(R.id.cb_leite);
        cbCarne = findViewById(R.id.cb_carne);
        cbFeijao = findViewById(R.id.cb_feijao);
        cbCoca = findViewById(R.id.cb_coca);
        btnCalcular = findViewById(R.id.btn_calcular);
        tvResultado = findViewById(R.id.tv_resultado);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double total = 0.0;

                if (cbArroz.isChecked()) total += 2.69;
                if (cbLeite.isChecked()) total += 2.70;
                if (cbCarne.isChecked()) total += 16.70;
                if (cbFeijao.isChecked()) total += 3.38;
                if (cbCoca.isChecked()) total += 3.00;

                tvResultado.setText(String.format("Total: R$ %.2f", total));

                btnCalcular.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean algumSelecionado = cbArroz.isChecked() || cbLeite.isChecked() ||
                                cbCarne.isChecked() || cbFeijao.isChecked() ||
                                cbCoca.isChecked();

                        if (!algumSelecionado) {
                            Toast.makeText(MainActivity.this, "Selecione pelo menos um item da lista!", Toast.LENGTH_SHORT).show();
                            return; // não continua o cálculo
                        }

                        double total = 0.0;

                        if (cbArroz.isChecked()) total += 2.69;
                        if (cbLeite.isChecked()) total += 2.70;
                        if (cbCarne.isChecked()) total += 16.70;
                        if (cbFeijao.isChecked()) total += 3.38;
                        if (cbCoca.isChecked()) total += 3.00;

                        tvResultado.setText(String.format("Total: R$ %.2f", total));
                    }
                });

            }
        });
    }
}
